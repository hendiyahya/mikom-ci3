-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for dbtubes
CREATE DATABASE IF NOT EXISTS `dbtubes` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `dbtubes`;

-- Dumping structure for table dbtubes.hendi_categories
CREATE TABLE IF NOT EXISTS `hendi_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dbtubes.hendi_categories: ~5 rows (approximately)
REPLACE INTO `hendi_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
	(1, 'Administrasi', 'administrasi', '2022-12-06 21:03:18', '2022-12-06 21:03:18'),
	(2, 'Akademik', 'akademik', '2022-12-06 21:03:18', '2022-12-06 21:03:18'),
	(3, 'Organisasi', 'organisasi', '2022-12-06 21:03:18', '2022-12-06 21:03:18'),
	(4, 'Birokrasi', 'birokrasi', '2022-12-06 21:03:18', '2022-12-06 21:03:18'),
	(5, 'Teknologi', 'teknologi', '2022-12-06 21:03:18', '2022-12-06 21:03:18');

-- Dumping structure for table dbtubes.hendi_comments
CREATE TABLE IF NOT EXISTS `hendi_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `post_id` bigint unsigned NOT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dbtubes.hendi_comments: ~6 rows (approximately)
REPLACE INTO `hendi_comments` (`id`, `user_id`, `post_id`, `parent_id`, `body`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 2, 1, NULL, 'Masuk Ke Halaman Layanan Surat FPMIPA', '2022-12-06 21:05:59', '2022-12-06 21:05:59', NULL),
	(2, 3, 2, NULL, 'Masuk Ke halaman IRS di SIAK', '2022-12-06 21:28:11', '2022-12-06 21:28:11', NULL),
	(3, 4, 3, NULL, 'Mengikuti kaderisasi dan mendaftar saat open recruitment', '2022-12-06 21:31:35', '2022-12-06 21:31:35', NULL),
	(4, 5, 4, NULL, 'Komunikasikan dengan petugas yang mengatur ruangan tersebut', '2022-12-19 08:05:37', '2022-12-19 08:05:37', NULL),
	(5, 1, 5, NULL, 'Metaverse memiliki dampak positif atau negatif tergantung pemakainya', '2022-12-19 08:05:36', '2022-12-19 08:05:38', NULL),
	(6, 1, 1, NULL, 'bisa diakses di http://layanansurat.fpmipa.upi.edu/', NULL, NULL, NULL),
	(15, 1, 1, NULL, 'a', NULL, NULL, NULL);

-- Dumping structure for table dbtubes.hendi_posts
CREATE TABLE IF NOT EXISTS `hendi_posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64021 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dbtubes.hendi_posts: ~5 rows (approximately)
REPLACE INTO `hendi_posts` (`id`, `category_id`, `user_id`, `title`, `image`, `excerpt`, `body`, `published_at`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, 'Cara Membuat Surat Aktif Kuliah', '-', '-', 'Bagaimana cara membuat surat aktif kuliah untuk keperluan lomba ?', NULL, '2022-12-19 08:01:40', '2022-12-19 08:01:41'),
	(2, 2, 2, 'Cara Cetak Transkrip', '-', '-', 'Bagaimana cara mencetak transkrip untuk kepentingan sebuah lomba atau administrasi ?', NULL, '2022-12-06 19:24:45', '2022-12-06 19:34:10'),
	(3, 3, 3, 'Cara Kontrak Kuliah', '-', '-', 'Bagaimana cara mengisi isian rencana studi (IRS) ?', NULL, '2022-12-06 19:24:45', '2022-12-06 19:34:10'),
	(4, 4, 4, 'Cara Izin Tempat FPMIPA', '-', '-', 'Bagaimana langkah perizinan penggunaan Student Corner ?', NULL, '2022-12-06 19:24:45', '2022-12-06 19:34:10'),
	(5, 5, 5, 'Metaverse', '-', '-', 'Apakah Metaverse memiliki prospek bagus untuk dipelajari ?', NULL, '2022-12-06 19:24:45', '2022-12-06 19:34:10');

-- Dumping structure for table dbtubes.hendi_users
CREATE TABLE IF NOT EXISTS `hendi_users` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table dbtubes.hendi_users: ~5 rows (approximately)
REPLACE INTO `hendi_users` (`id_user`, `nama`, `email`, `username`, `password`) VALUES
	(1, 'Hendi', 'yahyahendi35@gmail.com', 'hendiyahya', '5f4dcc3b5aa765d61d8327deb882cf99'),
	(2, 'Alghi', 'alghifary@gmail.com', 'alghifary', '5f4dcc3b5aa765d61d8327deb882cf99'),
	(3, 'makhi', 'makhi@gmail.com', 'makhi', '202cb962ac59075b964b07152d234b70'),
	(4, 'arumnenden', 'arumnenden@gmail.com', 'arumnenden', '5f4dcc3b5aa765d61d8327deb882cf99'),
	(5, 'ade ariyansyah', 'ariyansyah@gmail.com', 'ariyansyah', '5f4dcc3b5aa765d61d8327deb882cf99'),
	(7, 'zainul urfi', 'zainulurfi@gmail.com', 'urfi', '5f4dcc3b5aa765d61d8327deb882cf99');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
